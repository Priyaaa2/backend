package com.mphasis.jms.consumer;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.jms.Queue;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mphasis.jms.model.ExcelCellMessage;
import com.mphasis.jms.service.ExcelService;

@Service
public class MessageConsumer {

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	JmsTemplate jmsTemplate;
	
	@Autowired
	ExcelService excelService;

	@Autowired
	Queue queue;

	private static final Logger LOGGER = LoggerFactory.getLogger(MessageConsumer.class);

	@JmsListener(destination = "inMemory.queue")
	public void excelErrorListener(List<ExcelCellMessage> excelCellMessage) {
		System.out.println("Listening..");
		LOGGER.info("message " + "received {}", excelCellMessage);
		validateAndUpdateData(excelCellMessage);
		excelService.generateValidatedExcelCellMessage(excelCellMessage);
	}

	private void validateAndUpdateData(List<ExcelCellMessage> excelCellMessage) {

		for(ExcelCellMessage data : excelCellMessage) {
			if(StringUtils.isEmpty(data.getEmployeeId())
				|| StringUtils.isEmpty(data.getFirstName())
				|| StringUtils.isEmpty(data.getLastName())
				|| StringUtils.isEmpty(data.getRole())
				|| StringUtils.isEmpty(data.getDepartment())
				|| StringUtils.isEmpty(data.getSalary())) {
				data.setStatus("INVALID");
			} else {
				data.setStatus("VALID");
			}
		}
		
		ExcelService.setResponse(excelCellMessage);
		
	}
}
