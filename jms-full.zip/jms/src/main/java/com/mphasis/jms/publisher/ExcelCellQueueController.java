package com.mphasis.jms.publisher;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mphasis.jms.model.ExcelCellMessage;
import com.mphasis.jms.service.ExcelService;

@RestController
public class ExcelCellQueueController {

    @Autowired
    ExcelService excelService;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
        	System.out.println("Sending file...");
            excelService.upload(file);
            return new ResponseEntity<>("file uploaded, validating...", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/validatedResponse")
    public ResponseEntity<Object> getValidatedReponse() {
        try {
        	System.out.println("Getting response...");
            List<ExcelCellMessage> response = excelService.getResponseJson();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/validatedResponseFilePath")
    public ResponseEntity<Object> getValidatedReponseFile() {
        try {
        	System.out.println("Getting response file...");
            List<ExcelCellMessage> response = excelService.getResponseJson();
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
