package com.mphasis.jms.model;

import java.io.Serializable;

public class ExcelCellMessage implements Serializable {

	private static final long serialVersionUID = 7077738031554276706L;

	private String employeeId;
	private String firstName;
	private String lastName;
	private String role;
	private String department;
	private String salary;
	private String status;

	public ExcelCellMessage(String employeeId, String firstName, String lastName, String role, String department,
			String salary, String status) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.role = role;
		this.department = department;
		this.salary = salary;
		this.status = status;
	}

	public ExcelCellMessage() {
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ExcelCellMessage [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", role=" + role + ", department=" + department + ", salary=" + salary + ", status=" + status + "]";
	}

}
