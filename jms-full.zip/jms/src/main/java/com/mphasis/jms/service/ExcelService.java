package com.mphasis.jms.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.jms.Queue;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mphasis.jms.model.ExcelCellMessage;

@Service
public class ExcelService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelService.class);
    
    @Autowired
    JmsTemplate jmsTemplate;
    
    @Autowired
    private Queue queue;
    
    static List<ExcelCellMessage> response = new ArrayList<>();

    public void upload(MultipartFile file) {
        try {
        	response = readExcelAndPushErrors(file.getInputStream());
            pushToJms();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void pushToJms() {
        LOGGER.info("Pushing data {}", response);
        jmsTemplate.convertAndSend(queue, response);
    }
 
    public static List<ExcelCellMessage> readExcelAndPushErrors(InputStream is) {
        try {
            Workbook workbook = new XSSFWorkbook(is);
            Sheet sheet = workbook.getSheet("Sheet1");
            Iterator<Row> rows = sheet.iterator();
            List<ExcelCellMessage> excelCellMessageList = new ArrayList<>();
            int rowNumber = 0;
            while (rows.hasNext()) {
                Row currentRow = rows.next();
                // skip header
                if (rowNumber == 0) {
                    rowNumber++;
                    continue;
                }
                Iterator<Cell> cellsInRow = currentRow.iterator();
                ExcelCellMessage excelCellMessage = new ExcelCellMessage();
                int cellIdx = 0;
                while (cellsInRow.hasNext()) {
                    Cell currentCell = cellsInRow.next();
                    if(currentCell != null) {
                    	switch (currentCell.getColumnIndex()) {
                        case 0:
                        	Double empId = currentCell.getNumericCellValue();
                            excelCellMessage.setEmployeeId(empId.toString());
                            break;
                        case 1:
                            excelCellMessage.setFirstName(currentCell.getStringCellValue());
                            break;
                        case 2:
                        	excelCellMessage.setLastName(currentCell.getStringCellValue());
                            break;
                        case 3:
                        	excelCellMessage.setRole(currentCell.getStringCellValue());
                            break;
                        case 4:
                        	Double salary = currentCell.getNumericCellValue();
                        	excelCellMessage.setSalary(salary.toString());
                            break;
                        case 5:
                        	excelCellMessage.setDepartment(currentCell.getStringCellValue());
                            break;
                                               	
                        default:
                            break;
                    }
                    }
                    
                    cellIdx++;
                }
                excelCellMessageList.add(excelCellMessage);
            }
            workbook.close();
            return excelCellMessageList;
        } catch (Exception e) {
        	e.printStackTrace();
            throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
        }
    }
    
    public void generateValidatedExcelCellMessage(List<ExcelCellMessage> excelCellMessages) {

		  //Blank workbook
      XSSFWorkbook workbook = new XSSFWorkbook(); 
       
      //Create a blank sheet
      XSSFSheet sheet = workbook.createSheet("EmployeeData");
        
      //This data needs to be written (Object[])
      Map<String, Object[]> data = new TreeMap<String, Object[]>();
      data.put("0", new Object[] {"EmployeeID", "FirstName", "LastName", "Role", "Salary", "Department", "ValidationStatus"});
      Integer i = 0;
      for(; i< excelCellMessages.size(); i++) {
    	  String idxStr = new Integer((i + 1)).toString();
    	  
          data.put(idxStr, new Object[] {excelCellMessages.get(i).getEmployeeId(),
          		excelCellMessages.get(i).getFirstName(),
          		excelCellMessages.get(i).getLastName(),
          		excelCellMessages.get(i).getRole(),
          		excelCellMessages.get(i).getSalary(),
          		excelCellMessages.get(i).getDepartment(),
          		excelCellMessages.get(i).getStatus()});
      }
        
      //Iterate over data and write to sheet
      Set<String> keyset = data.keySet();
      int rownum = 0;
      for (String key : keyset)
      {
          Row row = sheet.createRow(rownum++);
          Object [] objArr = data.get(key);
          int cellnum = 0;
          for (Object obj : objArr)
          {
             Cell cell = row.createCell(cellnum++);
             if(obj instanceof String) {
            	 cell.setCellType(CellType.STRING);
            	 cell.setCellValue((String)obj);
             }else if(obj instanceof Integer) {
            	 cell.setCellType(CellType.NUMERIC);
            	 cell.setCellValue((Integer)obj);
             }
                  
          }
      }
      try
      {
          //Write the workbook in file system
          FileOutputStream out = new FileOutputStream(new File("ValidatedEmployees.xlsx"));
          workbook.write(out);
          out.close();
          System.out.println("ValidatedEmployees.xlsx written successfully on disk.");
      } 
      catch (Exception e) 
      {
          e.printStackTrace();
      }
		
		
	}

	public List<ExcelCellMessage> getResponseJson() {
		return getResponse();
	}

	public static List<ExcelCellMessage> getResponse() {
		return response;
	}

	public static void setResponse(List<ExcelCellMessage> response) {
		ExcelService.response = response;
	}
	
	
}
